
import Controladores.LeerArchivo;
import Controladores.NumerosPalindromos;
import java.io.*;

public class Main {

    public static void main(String[] args) {
        // Instanciar las clases
        LeerArchivo lector = new LeerArchivo();
        NumerosPalindromos palindromoUtil = new NumerosPalindromos();

        try {
            // Leer el archivo
            String rutaArchivo = "data.txt";
            int[] numeros = lector.leerArchivo(rutaArchivo);

            // Inicializar variables
            int[] palindromos = new int[numeros.length];
            int contador = 0;
            long inicioTiempo = System.currentTimeMillis(); // Inicia el cálculo de tiempo

            // Verificar cuáles son palíndromos
            for (int num : numeros) {
                if (palindromoUtil.esPalindromo(num)) {
                    palindromos[contador] = num; // Guardar el número en el arreglo
                    contador++;
                }
            }

            // Mostrar resultados
            System.out.println("Cantidad de números palíndromos encontrados: " + contador);
            System.out.println("Números palíndromos encontrados:");
            for (int i = 0; i < contador; i++) {
                System.out.println(palindromos[i]);
            }

            // Calcular el tiempo total de ejecución
            long finTiempo = System.currentTimeMillis();
            long sumaTotalTiempo = finTiempo - inicioTiempo;
            System.out.println("Tiempo total de ejecución: " + sumaTotalTiempo + " ms");

        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        }
    }
}