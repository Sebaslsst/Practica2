public class LinkedList<E> {
    private Node<E> head;
    private int size;

    public LinkedList() { head = null; size = 0; }

    public void add(E data) {
        Node<E> new Node = new Node<>(data);
        if (head == null) { head = new Node; }
        else {
            Node<E> temp = head;
            while (temp.getNext() != null) { temp = temp.getNext(); }
            temp.setNext(new Node);
        }
        size++;
    }

    public void print() {
        Node<E> temp = head;
        while (temp != null) {
            System.out.print(temp.getData() + " -> ");
            temp = temp.getNext();
        }
        System.out.println("null");
    }
}