import java.util.*;

public class tiempo {
    public static void main(String[] args) {
        LinkedList<Integer> lista = new LinkedList<>();
        int[] arreglo;

        try {
            List<Integer> datos = DataLoader.leerArchivo("data.txt");
            arreglo = new int[datos.size()];
            for (int i = 0; i < datos.size(); i++) {
                lista.add(datos.get(i));
                arreglo[i] = datos.get(i);
            }

            System.out.println("Lista Enlazada:");
            lista.print();
            System.out.println("Arreglo:");
            System.out.println(Arrays.toString(arreglo));

        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        }
    }
}