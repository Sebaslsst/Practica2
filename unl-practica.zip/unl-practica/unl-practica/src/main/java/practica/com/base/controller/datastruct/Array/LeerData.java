
import java.io.*;

public class LeerArchivo {

    // Método para leer el archivo y devolver los números como un arreglo
    public int[] leerArchivo(String rutaArchivo) throws IOException {
        BufferedReader file = new BufferedReader(new FileReader(rutaArchivo));
        String line;
        int contador = 0;

        // Contar el número de líneas en el archivo para crear el arreglo
        while ((line = file.readLine()) != null) {
            contador++;
        }
        file.close();

        // Crear el arreglo con el tamaño adecuado
        int[] numeros = new int[contador];

        // Leer el archivo nuevamente para llenar el arreglo
        file = new BufferedReader(new FileReader(rutaArchivo));
        int index = 0;

        while ((line = file.readLine()) != null) {
            numeros[index] = Integer.parseInt(line.trim());
            index++;
        }

        file.close(); // Cerrar el archivo
        return numeros; // Devolver el arreglo de números
    }
}