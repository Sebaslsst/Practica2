import java.io.*;
import java.util.*;

public class DataLoader {
    public static List<Integer> leerArchivo(String "data.txt") throws IOException {
        List<Integer> datos = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("data.txt"))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                datos.add(Integer.parseInt(linea.trim()));
            }
        }
        return datos;
    }
}